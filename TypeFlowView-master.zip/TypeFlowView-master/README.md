# TypeFlowView
一个在 UITextView 中逐字显示文本的打字机动画效果，并动态调整光标位置的 demo。 
A demo that simulates a typewriter effect by displaying text character by character in a UITextView, with dynamic cursor position adjustment.
