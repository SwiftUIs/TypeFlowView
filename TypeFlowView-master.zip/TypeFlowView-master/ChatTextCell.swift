import UIKit

class ChatTextCell: UITableViewCell {
    private lazy var textView: UITextView = {
        let view = UITextView()
        view.font = .systemFont(ofSize: 18, weight: .semibold)
        view.textColor = .black
        view.backgroundColor = .green.withAlphaComponent(0.1)
        view.isEditable = false
        view.textContainerInset = .zero
        view.textContainer.lineFragmentPadding = 0
        return view
    }()
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        
        contentView.addSubview(textView)
        contentView.backgroundColor = .white  // ✅ 确保 cell 是可见的
        textView.isScrollEnabled = false  // ✅ 让 TextView 自适应高度
        
        textView.snp.makeConstraints { make in
            make.top.left.right.equalToSuperview().inset(10)
            make.bottom.equalToSuperview().offset(-10)
        }
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func configure(text: String) {
        textView.text = text
        updateText(text) // ✅ 初始化时立即调整高度
    }
    
    func updateText(_ text: String) {
          textView.text = text
          let newSize = textView.sizeThatFits(CGSize(width: contentView.bounds.width - 20, height: CGFloat.greatestFiniteMagnitude))

        textView.snp.remakeConstraints { make in
            make.top.left.right.equalToSuperview().inset(10)
            make.bottom.equalToSuperview().offset(-10)
            make.height.equalTo(newSize.height)  // ✅ 让 `UITextView` 根据内容自动调整高度
        }
          
          DispatchQueue.main.async {
              self.contentView.layoutIfNeeded() // ✅ 确保 `UITableViewCell` 立即刷新布局
          }
      }
}
