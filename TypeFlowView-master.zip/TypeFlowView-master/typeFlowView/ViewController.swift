import UIKit

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    private var messages: [String] = ["我们的同志在困难的时候，要看到成绩，要看到光明..."]
    
    private lazy var tableView: UITableView = {
        let tableView = UITableView()
        tableView.delegate = self
        tableView.dataSource = self
        tableView.register(ChatTextCell.self, forCellReuseIdentifier: "ChatTextCell")
        tableView.separatorStyle = .none
        tableView.estimatedRowHeight = 50
        tableView.rowHeight = UITableView.automaticDimension
        return tableView
    }()
    
    private lazy var addButton: UIButton = {
        let button = UIButton(type: .system)
        button.setTitle("添加消息", for: .normal)
        button.setTitleColor(.white, for: .normal)
        button.backgroundColor = .systemBlue
        button.layer.cornerRadius = 8
        button.addTarget(self, action: #selector(addNewMessage), for: .touchUpInside)
        return button
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        view.addSubview(tableView)
        view.addSubview(addButton)
        
        tableView.backgroundColor = .red
        tableView.snp.makeConstraints { make in
            make.top.left.right.equalToSuperview()
            make.bottom.equalToSuperview().offset(-60)
        }
        
        addButton.snp.makeConstraints { make in
            make.bottom.equalToSuperview().offset(-10)
            make.centerX.equalToSuperview()
            make.width.equalTo(120)
            make.height.equalTo(40)
        }
    }
    
    @objc private func addNewMessage() {
        let newIndex = messages.count
        messages.append("")  // ✅ 确保 messages 里有空字符串
                
        let newIndexPath = IndexPath(row: newIndex, section: 0)
        tableView.performBatchUpdates({
            tableView.insertRows(at: [newIndexPath], with: .fade)
        }) { _ in
            self.tableView.scrollToRow(at: newIndexPath, at: .bottom, animated: true)
            self.simulateReceivingText(fromAPIFor: newIndex)
        }
    }
    
    
    private func simulateReceivingText(fromAPIFor index: Int) {
        // 模拟从接口逐字接收文本
        let fullText = "我们的同志在困难的时候，要看到成绩，要看到光明..."
        
        // 模拟接口逐字返回
        var currentText = ""
        let delayPerChar = 0.1  // 模拟每个字符的延迟
        for (i, char) in fullText.enumerated() {
            DispatchQueue.main.asyncAfter(deadline: .now() + Double(i) * delayPerChar) {
                if index < self.messages.count {
                    currentText.append(char)
                    self.messages[index] = currentText

                    // 更新当前 cell 的显示内容
                    if let cell = self.tableView.cellForRow(at: IndexPath(row: index, section: 0)) as? ChatTextCell {
                        cell.updateText(self.messages[index])
                    }

                    if i % 5 == 0 {  // 例如每5个字符刷新一次，减少刷新频率
                        self.tableView.beginUpdates()
                        self.tableView.endUpdates()
                    }
                    
                    // 滚动到最新的消息
                    self.tableView.scrollToRow(at: IndexPath(row: index, section: 0), at: .bottom, animated: true)
                }
            }
        }
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        print("tableView 数据行数: \(messages.count)")  // ✅ 确保数据量
        return messages.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "ChatTextCell", for: indexPath) as! ChatTextCell
        let text = messages[indexPath.row]
        cell.configure(text: text)
        
        print("正在显示第 \(indexPath.row) 个 Cell，内容：\(text)") // ✅ 确保 Cell 被正确加载
        
        return cell
    }
}
